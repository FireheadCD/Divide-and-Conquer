// Connor Dysart
//CSC 130
//Prof. Mamoun
//10/14/2019

package Documents.Projects.Divide;

//importing Arrays and Scanner so the n element can be user put in with user input
import java.util.Arrays;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Conquer cls = new Conquer();


        //First we must create the two sorted arrays to divide and conquer
        int[] A = {0, 6, 19, 25, 96, 201, 9001};
        int[] B = {1, 15, 111, 202, 9000};

        //Lengths of the arrays
        int lengthA = A.length;
        int lengthB = B.length;

        //Displaying the arrays and taking in input for the nth largest value
        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));
        System.out.println("===============================================");
        System.out.println("To Which Nth Largest Value do You Want to Find: ");
        // This will scan and read the user input on the largest value to find
        int n = scan.nextInt();
        System.out.println("Finding " + n + "th largest variable");
        System.out.println("===============================================");
        //Calls upon the conquer method from the Conquer class
        System.out.println("The " + n + "th largest element is: " + cls.conquer(lengthA, lengthB, A, B, n));
    }
}

