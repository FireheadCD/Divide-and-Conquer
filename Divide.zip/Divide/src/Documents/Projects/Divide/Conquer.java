package Documents.Projects.Divide;

import java.util.Arrays;

public class Conquer{

public static int conquer(int lengthA, int lengthB, int[] A, int[] B, int n)
        {
        //finding the minimum value from the length of the array or half of the element value
        int middleA = Math.min(lengthA, n / 2);
        int middleB = Math.min(lengthB, n / 2);

        if ( lengthA > lengthB)
        return conquer(lengthB, lengthA, B, A, n);

        if (lengthA == 0)
        return B[n - 1];

        // if the n value is equal to one, return the min value of the 1st elements of
        if ( n == 1)
        return Math.min(A[0], B[0]);

        //c
        if ( A[middleA - 1] > B[middleB - 1])
        {
        int temp[] = Arrays.copyOfRange(B, middleB, lengthB);
        return conquer(lengthA, lengthB - middleB, A, temp, n - middleB );
        }
        int temp[] = Arrays.copyOfRange(A, middleA, lengthA);
        return conquer(lengthA - middleA, lengthB, temp, B, n - middleA);
        }
        }
